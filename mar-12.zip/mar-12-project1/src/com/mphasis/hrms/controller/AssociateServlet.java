package com.mphasis.hrms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mphasis.hrms.model.Associate;
import com.mphasis.hrms.model.AssociateDaoImpl;

import oracle.net.aso.a;

/**
 * Servlet implementation class AssociateServlet
 */
@WebServlet({ "/AssociateServlet", "/associate" })
public class AssociateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssociateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		Long associateId=Long.valueOf(request.getParameter("associateId"));
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String sdate="";
		sdate=request.getParameter("dateOfJoining");
		Date dateOfJoining=null;
		try {
			dateOfJoining=sdf.parse(sdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(dateOfJoining==null)
			return;
		String gender=request.getParameter("gender");
		Associate associate=new Associate(associateId, firstName, lastName, dateOfJoining, gender, null);
		AssociateDaoImpl adao=new AssociateDaoImpl();
		int no=0;
		try {
			no=adao.create(associate);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter out = response.getWriter();
		out.println(no+" row(s) affected");
		//		in adao, there is a method that returns all records
		List<Associate> associateList =null;
		try {
			associateList=adao.read();
		} catch (ClassNotFoundException | SQLException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(associateList==null)
			return;
		out.println("<table border=1>");
		out.println("<thead><th>Associate Id</th><th>First Name</th><th>Last Name</th>");
		out.println("<th>Date of Joining</th><th>Gender</th><th>Picture</th>");
		for(Associate a:associateList)
		{
			out.println("<tr>");
			out.println("<td>"+a.getAssociateId());
			out.println("</td>");
			out.println("<td>");
			out.println(a.getFirstName());
			out.println("</td>");
			out.println("<td>");
			out.println(a.getLastName());
			out.println("</td>");
			out.println("<td>");
			out.println(a.getDateOfJoining());
			out.println("</td>");
			out.println("<td>");
			out.println(a.getGender());
			out.println("</td>");
			out.println("<td>");
			out.println("under construction");
			out.println("</td>");
			
			
			out.println("</tr>");			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
